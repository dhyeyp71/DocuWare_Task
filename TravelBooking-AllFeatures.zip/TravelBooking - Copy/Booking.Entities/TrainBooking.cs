﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.Entities
{
    public class TrainBooking : BookingDetails
    {
        public string TrainNumber { get; set; } 
        public string Class { get; set; }

        public override string ToString()
        {
            return "Train Booking";
        }
    }
}
