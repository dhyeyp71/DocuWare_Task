﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public  class TrainBookingViewModel : BookingBaseViewModel
    {
        private string trainNumber;
        private string _class;
        private IBookingData dataAccess;

        public TrainBookingViewModel(User user)
        {
            PassangerDetail = user;
            dataAccess = new XmlDataAccess();
            SaveBookingCommand = new DelegateCommand(saveTrainBooking);
        }

        public string TrainNumber
        {
            get { return trainNumber; }
            set
            {
                trainNumber = value;
                RaisePropertyChanged(nameof(TrainNumber));
            }
        }

        public string Class
        {
            get { return _class; }
            set
            {
                _class = value;
                RaisePropertyChanged(nameof(Class));
            }
        }

        public event EventHandler NotifyClientHome;

        private void saveTrainBooking()
        {
            TrainBooking trainBooking = new TrainBooking();
            trainBooking.BookingId = Guid.NewGuid();
            trainBooking.Source = Source;
            trainBooking.Destination = Destination;
            trainBooking.TrainNumber = TrainNumber;
            trainBooking.SeatNumber = SeatNumber;
            trainBooking.DateOfDeparture = DepartureDate;
            trainBooking.TimeOfDeparture = DepartureTime;
            trainBooking.Passanger = (PassangerDetails)PassangerDetail;
            dataAccess.SaveBooking(trainBooking);

            NotifyClientHome?.Invoke(this, EventArgs.Empty);

        }
    }
}
