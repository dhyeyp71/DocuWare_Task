﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class ClientHomeViewModel : ViewModelBase
    {
        private ViewModelBase selectedViewModel;
        private BusBookingViewModel busViewModel;
        private PlaneBookingViewModel planeViewModel;
        private TrainBookingViewModel trainViewModel;
        private ObservableCollection<BookingDetails> _bookingList;
        private User userContext;
        private IBookingData dataAccess;


        public ClientHomeViewModel(User user)
        {
            userContext = user;
            dataAccess = new XmlDataAccess();

            NavCommand = new DelegateCommand<string>(OnNav);
            busViewModel = new BusBookingViewModel(user);
            planeViewModel = new PlaneBookingViewModel(user);
            trainViewModel = new TrainBookingViewModel(user);
            OnNav("Bus");
        }

        public ViewModelBase SelectedViewModel
        {
            get { return selectedViewModel; }
            set
            {
                selectedViewModel = value;
                RaisePropertyChanged(nameof(SelectedViewModel));
            }
        }

        public DelegateCommand<string> NavCommand { get; }


        public ObservableCollection<BookingDetails> BookingList
        {
            get { return _bookingList; }
            set
            {
                _bookingList = value;
                RaisePropertyChanged(nameof(BookingList));
            }
        }

        private void OnNav(string bookingType)
        {
            busViewModel.NotifyClientHome -= GetBookingHistory;
            trainViewModel.NotifyClientHome -= GetBookingHistory;
            planeViewModel.NotifyClientHome -= GetBookingHistory;

            switch (bookingType)
            {
                case "Bus":
                    busViewModel.NotifyClientHome += GetBookingHistory;
                    SelectedViewModel = busViewModel;
                    break;
                case "Train":
                    trainViewModel.NotifyClientHome += GetBookingHistory;
                    SelectedViewModel = trainViewModel;
                    break;
                case "Plane":
                    planeViewModel.NotifyClientHome += GetBookingHistory;
                    SelectedViewModel = planeViewModel;
                    break;
                default:
                    break;
            }
            GetBookingHistory(string.Empty, EventArgs.Empty);
        }

        private void GetBookingHistory(object e, EventArgs ea)
        {
             BookingList = new ObservableCollection<BookingDetails>(dataAccess.GetAllBookingDetails(userContext.UserId));
        }
    }
}
