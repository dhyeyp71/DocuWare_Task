﻿using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class BookingBaseViewModel : ViewModelBase
    {
        private string source;
        private string destination;
        private DateTime departureDate = DateTime.Today;
        private string departureTime;
        private string seatNumber;
        private User passangerDetail;

        public string Source
        {
            get { return source; }
            set 
            { 
                source = value; 
                RaisePropertyChanged(nameof(Source));
            }
        }

        public string Destination
        {
            get { return destination; }
            set
            {
                destination = value;
                RaisePropertyChanged(nameof(Destination));
            }
        }

        public DateTime DepartureDate
        {
            get { return departureDate; }
            set
            {
                departureDate = value;
                RaisePropertyChanged(nameof(DepartureDate));
            }
        }

        public string DepartureTime
        {
            get { return departureTime; }
            set
            {
                departureTime = value;
                RaisePropertyChanged(nameof(DepartureTime));
            }
        }

        public string SeatNumber
        {
            get { return seatNumber; }
            set
            {
                seatNumber = value;
                RaisePropertyChanged(nameof(SeatNumber));
            }
        }

        public User PassangerDetail
        {
            get { return passangerDetail; }
            set
            {
                passangerDetail = value;
                RaisePropertyChanged(nameof(PassangerDetail));
            }
        }

        public DelegateCommand SaveBookingCommand { get; protected set; }
    }
}
