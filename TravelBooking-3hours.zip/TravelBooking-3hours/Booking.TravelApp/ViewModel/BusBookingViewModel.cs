﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class BusBookingViewModel : BookingBaseViewModel
    {
        private string busNumber;
        private IBookingData dataAccess;

        public BusBookingViewModel(User user) 
        {
            PassangerDetail = user;
            dataAccess = new XmlDataAccess();
            SaveBookingCommand = new DelegateCommand(saveBusBooking);
        }

        public string BusNumber
        {
            get { return busNumber; }
            set
            {
                busNumber = value;
                RaisePropertyChanged(nameof(BusNumber));
            }
        }

        public event EventHandler NotifyClientHome;

        private void saveBusBooking()
        {
            BusBooking busBooking = new BusBooking();
            busBooking.BookingId = Guid.NewGuid();
            busBooking.Source = Source;
            busBooking.Destination = Destination;
            busBooking.BusNumber = BusNumber;
            busBooking.SeatNumber = SeatNumber;
            busBooking.DateOfDeparture = DepartureDate;
            busBooking.TimeOfDeparture = DepartureTime;
            busBooking.Passanger = (PassangerDetails) PassangerDetail;

            dataAccess.SaveBooking(busBooking);

            NotifyClientHome?.Invoke(this, EventArgs.Empty);
        }

        private void GetBookingHistory()
        {
            dataAccess.GetAllBookingDetails(PassangerDetail.UserId);
        }

    }
}
