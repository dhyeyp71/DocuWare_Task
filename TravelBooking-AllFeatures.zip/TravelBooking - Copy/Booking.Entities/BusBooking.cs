﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.Entities
{
    public class BusBooking : BookingDetails
    {
        public string BusNumber { get; set; }

        public override string ToString()
        {
            return "Bus Booking";
        }
    }
}
