﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class PlaneBookingViewModel : BookingBaseViewModel
    {
        private string flightNumber;
        private string _class;
        private IBookingData dataAccess;

        public PlaneBookingViewModel(User user)
        {
            PassangerDetail = user;
            dataAccess = new XmlDataAccess();
            SaveBookingCommand = new DelegateCommand(savePlaneBooking);
        }

        public string FlightNumber
        {
            get { return flightNumber; }
            set
            {
                flightNumber = value;
                RaisePropertyChanged(nameof(FlightNumber));
            }
        }

        public string Class
        {
            get { return _class; }
            set
            {
                _class = value;
                RaisePropertyChanged(nameof(Class));
            }
        }

        public event EventHandler NotifyClientHome;


        private void savePlaneBooking()
        {
            PlaneBooking planeBooking = new PlaneBooking();
            planeBooking.BookingId = Guid.NewGuid();
            planeBooking.Source = Source;
            planeBooking.Destination = Destination;
            planeBooking.PlaneNumber = FlightNumber;
            planeBooking.SeatNumber = SeatNumber;
            planeBooking.DateOfDeparture = DepartureDate;
            planeBooking.TimeOfDeparture = DepartureTime;
            planeBooking.Passanger = (PassangerDetails)PassangerDetail;
            dataAccess.SaveBooking(planeBooking);
            NotifyClientHome?.Invoke(this, EventArgs.Empty);

        }
    }
}
