﻿using Booking.Entities;
using Booking.TravelApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Booking.TravelApp
{
    public class MainViewModel : ViewModelBase
    {
        private ViewModelBase selectedViewModel;
        private Visibility contentControlVisility;
        private Visibility loginVisibility;

        public MainViewModel() 
        {
            LoginCommand = new DelegateCommand(NavOnLogin);
        }

        public ViewModelBase SelectedViewModel 
        {
            get { return selectedViewModel; }
            set
            {
                selectedViewModel = value;
                RaisePropertyChanged(nameof(SelectedViewModel));
            }
        }

        public ObservableCollection<User> Users 
        { 
            get 
            { 
                return new ObservableCollection<User>(GetUsers()); 
            } 
        }

        public User SelectedUser { get; set; }

        public ObservableCollection<string> UserTypes 
        { 
            get
            {
                return new ObservableCollection<string>() { "Traveller", "Staff Member" };
            }
        }

        public string SelectedUserType { get; set; }

        public Visibility LoginVisibility 
        {
            get
            {
                return loginVisibility;
            }
            set
            {
                loginVisibility = value;
                RaisePropertyChanged(nameof(LoginVisibility));
            }
        }

        public Visibility ContentControlVisibility 
        {
            get
            {
                return contentControlVisility;
            }
            set
            {
                contentControlVisility = value;
                RaisePropertyChanged(nameof(ContentControlVisibility));
            }
        }


        public DelegateCommand LoginCommand { get; private set; }

        private void NavOnLogin()
        {
            switch (SelectedUserType)
            {
                case "Traveller":
                    ContentControlVisibility = Visibility.Visible;
                    LoginVisibility = Visibility.Collapsed;
                    SelectedViewModel = new ClientHomeViewModel(
                        new PassangerDetails()
                        {
                            FirstName = SelectedUser.FirstName,
                            LastName = SelectedUser.LastName,
                            Email = SelectedUser.Email,
                            Age = SelectedUser.Age,
                            UserId = SelectedUser.UserId
                        });
                    break;
                case "Staff Member":
                    ContentControlVisibility = Visibility.Visible;
                    LoginVisibility = Visibility.Collapsed;
                    SelectedViewModel = new StaffHomeViewModel(
                        new StaffMemberDetails()
                        {
                            FirstName = SelectedUser.FirstName,
                            LastName = SelectedUser.LastName,
                            Email = SelectedUser.Email,
                            Age = SelectedUser.Age,
                            UserId = SelectedUser.UserId
                        });
                    break;
                default:
                    break;
            }
        }

        private List<User> GetUsers()
        {
            List<User> users = new List<User>();
            var user = new User();
            user.FirstName = "TestFirst1";
            user.LastName = "TestLast1";
            user.UserId = 11;
            user.Age = 28;
            user.Email = "test1.test1@gmail.com";
            users.Add(user);

            user = new User();
            user.FirstName = "TestFirst2";
            user.LastName = "TestLast2";
            user.UserId = 12;
            user.Age = 23;
            user.Email = "test2.test2@gmail.com";
            users.Add(user);

            user = new User();
            user.FirstName = "TestFirst3";
            user.LastName = "TestLast3";
            user.UserId = 13;
            user.Age = 24;
            user.Email = "test3.test3@gmail.com";
            users.Add(user);

            user = new User();
            user.FirstName = "TestFirst4";
            user.LastName = "TestLast4";
            user.UserId = 14;
            user.Age = 33;
            user.Email = "test4.test4@gmail.com";
            users.Add(user);

            return users;
        }


    }
}
