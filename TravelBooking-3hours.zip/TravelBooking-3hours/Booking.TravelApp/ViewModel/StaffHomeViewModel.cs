﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class StaffHomeViewModel : ViewModelBase
    {
        private ViewModelBase selectedViewModel;
        private SearchBookingViewModel searchBookingViewModel;
        private StaffOperationsViewModel staffOperationsViewModel;
        private User userContext;
        private IBookingData dataAccess;

        public StaffHomeViewModel(User user)
        {
            userContext = user;
            dataAccess = new XmlDataAccess();
            NavCommand = new DelegateCommand<string>(OnNav);
            searchBookingViewModel = new SearchBookingViewModel(user);
            staffOperationsViewModel = new StaffOperationsViewModel(user);
            OnNav("CustomerBookings");
        }

        public ViewModelBase SelectedViewModel
        {
            get { return selectedViewModel; }
            set
            {
                selectedViewModel = value;
                RaisePropertyChanged(nameof(SelectedViewModel));
            }
        }

        public DelegateCommand<string> NavCommand { get; }

        private void OnNav(string bookingType)
        {
            switch (bookingType)
            {
                case "CustomerBookings":
                    SelectedViewModel = searchBookingViewModel;
                    break;
                case "StaffOperations":
                    SelectedViewModel = staffOperationsViewModel;
                    break;
                default:
                    break;
            }
        }


    }
}
