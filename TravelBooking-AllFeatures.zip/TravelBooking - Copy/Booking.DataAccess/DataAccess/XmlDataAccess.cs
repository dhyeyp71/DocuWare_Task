﻿using Booking.Entities;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Booking.DataAccess.DataAccess
{
    public class XmlDataAccess : IBookingData
    {
        private string xmlRepository = "./Repository/"; // "../../Repository"
        private string backupRepository = "./Backup/";
        private string backupFileName = "BookingArchieve.zip";

        public XmlDataAccess()
        {

        }

        public XmlDataAccess(string xmlRepository, string backupRepository)
        {
            this.xmlRepository = xmlRepository;
            this.backupRepository = backupRepository;
        }

        public bool SaveBooking(BookingDetails bookingDetails)
        {
            bool result = true;
            try
            {
                Directory.CreateDirectory(xmlRepository);

                string filePath = Path.Combine(xmlRepository, bookingDetails.Passanger?.UserId + ".xml");

                List<BookingDetails> bookingList = new List<BookingDetails>();

                if (File.Exists(filePath))
                {
                    //Get details from xml
                    bookingList = DeserializeBookingDetails(filePath);
                }

                if (bookingList != null)
                {
                    bookingList.Add(bookingDetails);
                    //recreate xml
                    SerializeBookingDetails(bookingList, filePath);
                }
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }

        public List<BookingDetails> GetAllBookingDetails(long clientId = 0)
        {
            string[] files;
            List<BookingDetails> bd = new List<BookingDetails>();

            try
            {
                if (!Directory.Exists(xmlRepository))
                {
                    return bd;
                }

                if (clientId > 0)
                {
                    files = new string[] { xmlRepository + "/" + clientId + ".xml" };
                }
                else
                {
                    files = Directory.GetFiles(xmlRepository, "*.xml", SearchOption.AllDirectories);
                }

                foreach (string file in files)
                {
                    if (File.Exists(file))
                    {
                        bd.AddRange(DeserializeBookingDetails(file));
                    }
                }
            }
            catch (Exception) { }

            return bd;
        }

        public bool BackupBookings()
        {
            try
            {
                if (!Directory.Exists(xmlRepository) || Directory.GetFiles(xmlRepository, "*.xml", SearchOption.AllDirectories).Length == 0)
                {
                    return false;
                }

                Directory.CreateDirectory(backupRepository);

                string buFilePath = Path.Combine(backupRepository, backupFileName);
                if (File.Exists(buFilePath))
                {
                    string renameFile = Path.Combine(backupRepository, "BookingArchieve_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + ".zip");
                    File.Move(buFilePath, renameFile);
                }
                ZipFile.CreateFromDirectory(xmlRepository, buFilePath);
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }


        private void SerializeBookingDetails(List<BookingDetails> bd, string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<BookingDetails>));
                using (TextWriter writer = new StreamWriter(filePath))
                {
                    serializer.Serialize(writer, bd);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private List<BookingDetails> DeserializeBookingDetails(string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<BookingDetails>));
                using (TextReader reader = new StreamReader(filePath))
                {
                    return (List<BookingDetails>)serializer.Deserialize(reader);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
