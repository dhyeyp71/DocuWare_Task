﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Booking.TravelApp.ViewModel
{
    public class BusBookingViewModel : BookingBaseViewModel
    {
        private string busNumber;
        private IBookingData dataAccess;

        public BusBookingViewModel(User user) 
        {
            PassangerDetail = user;
            dataAccess = new XmlDataAccess();
            SaveBookingCommand = new DelegateCommand(saveBusBooking);
        }

        public string BusNumber
        {
            get { return busNumber; }
            set
            {
                busNumber = value;
                RaisePropertyChanged(nameof(BusNumber));
            }
        }

        public event EventHandler NotifyClientHome;

        private void saveBusBooking()
        {
            BusBooking busBooking = new BusBooking();
            busBooking.BookingId = Guid.NewGuid();
            busBooking.Source = Source;
            busBooking.Destination = Destination;
            busBooking.BusNumber = BusNumber;
            busBooking.SeatNumber = SeatNumber;
            busBooking.DateOfDeparture = DepartureDate;
            busBooking.TimeOfDeparture = DepartureTime;
            busBooking.Passanger = (PassangerDetails) PassangerDetail;

            var result = dataAccess.SaveBooking(busBooking);

            if (result)
            {
                var message = string.Empty;
                XmlSerializer serializer = new XmlSerializer(typeof(BusBooking));
                using (StringWriter writer = new StringWriter())
                {
                    serializer.Serialize(writer, busBooking);
                    message = writer.ToString();
                }
                MessageBox.Show(message, "Booking");
                ResetFields();
            }
            else
            {
                MessageBox.Show("Error while booking.", "Booking");
            }

            NotifyClientHome?.Invoke(this, EventArgs.Empty);
        }

        private void GetBookingHistory()
        {
            dataAccess.GetAllBookingDetails(PassangerDetail.UserId);
        }

        private void ResetFields()
        {
            Source = string.Empty;
            Destination = string.Empty;
            BusNumber = string.Empty;
            SeatNumber = string.Empty;
            DepartureDate = DateTime.Today;
            DepartureTime = string.Empty;
        }

    }
}
