﻿using System.Xml.Serialization;

namespace Booking.Entities
{
    [XmlInclude(typeof(BusBooking)), 
     XmlInclude(typeof(PlaneBooking)),
     XmlInclude(typeof(TrainBooking))]
    public class BookingDetails
    {
        public Guid BookingId { get; set; }
        public string Source {  get; set; }
        public string Destination { get; set; }
        public DateTime DateOfDeparture { get; set; }
        public string TimeOfDeparture { get; set; }
        public string SeatNumber { get; set; }

        private PassangerDetails passanger;
        public PassangerDetails Passanger
        {
            get { return passanger; }
            set
            {
                if (value == null)
                {
                    value = new PassangerDetails();
                }
                passanger = value;
            }
        }
    }
}
