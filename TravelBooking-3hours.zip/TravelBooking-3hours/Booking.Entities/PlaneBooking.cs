﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.Entities
{
    public class PlaneBooking : BookingDetails
    {
        public string PlaneNumber { get; set; }
        public string Class { get; set; }

    }
}
