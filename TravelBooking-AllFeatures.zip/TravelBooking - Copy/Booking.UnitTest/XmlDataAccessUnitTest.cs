using Booking.DataAccess.DataAccess;
using Booking.Entities;

namespace Booking.UnitTest
{
    [TestClass]
    public class XmlDataAccessUnitTest
    {

        [TestMethod]
        public void SaveBookingTest1()
        {
            XmlDataAccess da = new XmlDataAccess(Data.xmlRepository, Data.backupRepository);
            ClearRepository();
            Assert.IsTrue(da.SaveBooking(Data.bookingDetails[0]));
        }

        [TestMethod]
        public void SaveBookingTest2()
        {
            XmlDataAccess da = new XmlDataAccess(Data.xmlRepository, Data.backupRepository);
            ClearRepository();
            Assert.IsTrue(da.SaveBooking(Data.bookingDetails[3]));
        }

        [TestMethod]
        public void SaveBookingTest3()
        {
            XmlDataAccess da = new XmlDataAccess(string.Empty, string.Empty);
            ClearRepository();
            Assert.IsFalse(da.SaveBooking(Data.bookingDetails[1]));
        }

        [TestMethod]
        public void GetAllBookingDetailsTest1()
        {
            XmlDataAccess da = new XmlDataAccess(Data.xmlRepository, Data.backupRepository);
            ClearRepository();

            da.SaveBooking(Data.bookingDetails[0]);
            da.SaveBooking(Data.bookingDetails[1]);
            da.SaveBooking(Data.bookingDetails[2]);

            Assert.AreEqual(3, da.GetAllBookingDetails().Count());
            Assert.AreEqual(2, da.GetAllBookingDetails(11).Count());
            Assert.AreEqual("train_source", da.GetAllBookingDetails(12).First().Source);
        }

        [TestMethod]
        public void GetAllBookingDetailsTest2()
        {
            XmlDataAccess da = new XmlDataAccess(string.Empty, string.Empty);
            ClearRepository();

            Assert.AreEqual(0, da.GetAllBookingDetails().Count());
            Assert.AreEqual(0, da.GetAllBookingDetails(11).Count());
        }


        [TestMethod]
        public void BackupBookingsTest1()
        {
            ClearRepository();
            XmlDataAccess da = new XmlDataAccess(Data.xmlRepository, Data.backupRepository);
            bool isDirectoryExist = Directory.Exists(Data.backupRepository);
            int fileCount = 0;
            if (isDirectoryExist)
            {
                fileCount = Directory.GetFiles(Data.backupRepository, "BookingArchieve*.zip", SearchOption.AllDirectories).Length;
            }

            da.SaveBooking(Data.bookingDetails[0]);

            Assert.IsTrue(da.BackupBookings());

            Assert.AreEqual(fileCount + 1, Directory.GetFiles(Data.backupRepository, "BookingArchieve*.zip", SearchOption.AllDirectories).Length);
        }


        [TestMethod]
        public void BackupBookingsTest2()
        {
            ClearRepository();
            XmlDataAccess da = new XmlDataAccess(Data.xmlRepository, Data.backupRepository);
            Assert.IsFalse(da.BackupBookings());
        }

        [TestMethod]
        public void BackupBookingsTest3()
        {
            ClearRepository();
            XmlDataAccess da = new XmlDataAccess(string.Empty, string.Empty);
            Assert.IsFalse(da.BackupBookings());
        }

        [TestMethod]
        public void BackupBookingsTest4()
        {
            ClearRepository();
            XmlDataAccess da = new XmlDataAccess(string.Empty, Data.backupRepository);

            Assert.IsFalse(da.BackupBookings());
        }

        private void ClearRepository()
        {
            if (Directory.Exists(Data.xmlRepository))
            {
                Directory.Delete(Data.xmlRepository, true);
            }
        }
    }
}