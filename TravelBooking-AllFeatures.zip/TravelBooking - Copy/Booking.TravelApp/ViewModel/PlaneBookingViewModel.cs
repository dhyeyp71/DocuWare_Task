﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Booking.TravelApp.ViewModel
{
    public class PlaneBookingViewModel : BookingBaseViewModel
    {
        private string flightNumber;
        private string _class;
        private IBookingData dataAccess;

        public PlaneBookingViewModel(User user)
        {
            PassangerDetail = user;
            dataAccess = new XmlDataAccess();
            SaveBookingCommand = new DelegateCommand(savePlaneBooking);
        }

        public string FlightNumber
        {
            get { return flightNumber; }
            set
            {
                flightNumber = value;
                RaisePropertyChanged(nameof(FlightNumber));
            }
        }

        public string Class
        {
            get { return _class; }
            set
            {
                _class = value;
                RaisePropertyChanged(nameof(Class));
            }
        }

        public event EventHandler NotifyClientHome;


        private void savePlaneBooking()
        {
            PlaneBooking planeBooking = new PlaneBooking();
            planeBooking.BookingId = Guid.NewGuid();
            planeBooking.Source = Source;
            planeBooking.Destination = Destination;
            planeBooking.PlaneNumber = FlightNumber;
            planeBooking.SeatNumber = SeatNumber;
            planeBooking.DateOfDeparture = DepartureDate;
            planeBooking.TimeOfDeparture = DepartureTime;
            planeBooking.Passanger = (PassangerDetails)PassangerDetail;

            var result = dataAccess.SaveBooking(planeBooking);
            if (result)
            {
                var message = string.Empty;
                XmlSerializer serializer = new XmlSerializer(typeof(PlaneBooking));
                using (StringWriter writer = new StringWriter())
                {
                    serializer.Serialize(writer, planeBooking);
                    message = writer.ToString();
                }
                MessageBox.Show(message, "Booking");
                ResetFields();
            }
            else
            {
                MessageBox.Show("Error while booking.", "Booking");
            }

            NotifyClientHome?.Invoke(this, EventArgs.Empty);

        }
        private void ResetFields()
        {
            Source = string.Empty;
            Destination = string.Empty;
            FlightNumber = string.Empty;
            Class = string.Empty;
            SeatNumber = string.Empty;
            DepartureDate = DateTime.Today;
            DepartureTime = string.Empty;
        }
    }
}
