﻿using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.UnitTest
{
    public class Data
    {
        internal static string xmlRepository = "./RepositoryUnitTest/";
        internal static string backupRepository = "./BackupUnitTest/";
        internal static string backupFileName = "BookingArchieve.zip";
        internal static  List<User> users = new List<User>();
        internal static  List<BookingDetails> bookingDetails = new List<BookingDetails>();

        static Data()
        {
            InitializeUsers();
            InitializeBookings();
        }

        private static void InitializeUsers()
        {
            var user = new PassangerDetails();
            user.FirstName = "TestFirst1";
            user.LastName = "TestLast1";
            user.UserId = 11;
            user.Age = 28;
            user.Email = "test1.test1@gmail.com";
            users.Add(user);

            user = new PassangerDetails();
            user.FirstName = "TestFirst2";
            user.LastName = "TestLast2";
            user.UserId = 12;
            user.Age = 23;
            user.Email = "test2.test2@gmail.com";
            users.Add(user);

            user = new PassangerDetails();
            user.FirstName = "TestFirst3";
            user.LastName = "TestLast3";
            user.UserId = 13;
            user.Age = 24;
            user.Email = "test3.test3@gmail.com";
            users.Add(user);

            user = new PassangerDetails();
            user.FirstName = "TestFirst4";
            user.LastName = "TestLast4";
            user.UserId = 14;
            user.Age = 33;
            user.Email = "test4.test4@gmail.com";
            users.Add(user);
        }

        private static void InitializeBookings()
        {
            BusBooking busBooking = new BusBooking();
            busBooking.BookingId = Guid.NewGuid();
            busBooking.Source = "bus_source";
            busBooking.Destination = "bus_destination";
            busBooking.BusNumber = "bus_number";
            busBooking.SeatNumber = "bus_seat_number";
            busBooking.DateOfDeparture = DateTime.Now;
            busBooking.TimeOfDeparture = "10:00 AM";
            busBooking.Passanger = (PassangerDetails)users[0];

            PlaneBooking planeBooking = new PlaneBooking();
            planeBooking.BookingId = Guid.NewGuid();
            planeBooking.Source = "plane_source";
            planeBooking.Destination = "plane_destination";
            planeBooking.PlaneNumber = "flight_number";
            planeBooking.SeatNumber = "flight_seat_number";
            planeBooking.DateOfDeparture = DateTime.Now;
            planeBooking.TimeOfDeparture = "11:00 AM";
            planeBooking.Passanger = (PassangerDetails)users[0];

            TrainBooking trainBooking = new TrainBooking();
            trainBooking.BookingId = Guid.NewGuid();
            trainBooking.Source = "train_source";
            trainBooking.Destination = "train_destination";
            trainBooking.TrainNumber = "train_number";
            trainBooking.SeatNumber = "train_seat_number";
            trainBooking.DateOfDeparture = DateTime.Now;
            trainBooking.TimeOfDeparture = "12:00 noon";
            trainBooking.Passanger = (PassangerDetails)users[1];

            BusBooking emptyBusBooking = new BusBooking();

            bookingDetails.Add(busBooking);
            bookingDetails.Add(trainBooking);
            bookingDetails.Add(planeBooking);
            bookingDetails.Add(emptyBusBooking);
        }
    }
}
