﻿using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Booking.DataAccess.DataAccess
{
    public class XmlDataAccess : IBookingData
    {
        private string xmlRepository = "./Repository"; // "../../Repository"

        public bool SaveBooking(BookingDetails bookingDetails)
        {
            bool result = false;
            Directory.CreateDirectory(xmlRepository);

            string filePath = Path.Combine(xmlRepository, bookingDetails.Passanger.UserId + ".xml");

            List<BookingDetails> bookingList = new List<BookingDetails>();

            if(File.Exists(filePath))
            {
                //Get details from xml
                bookingList = DeserializeBookingDetails(filePath);
            }

            if(bookingList != null)
            {
                bookingList.Add(bookingDetails);
                //recreate xml
                SerializeBookingDetails(bookingList, filePath);
            }

            return result;
        }

        public List<BookingDetails> GetAllBookingDetails(long clientId = 0)
        {
            string[] files;
            List<BookingDetails> bd = new List<BookingDetails>();

            if(clientId > 0 )
            {
                files = new string[] { xmlRepository + "/" + clientId + ".xml" };
            }
            else
            {
                files = Directory.GetFiles(xmlRepository, "*.xml", SearchOption.AllDirectories);
            }

            foreach(string file in files)
            {
                if(File.Exists(file))
                {
                    bd.AddRange(DeserializeBookingDetails(file));
                }
            }

            return bd;
        }

        public bool BackupBookings()
        {
            throw new NotImplementedException();
        }


        private void SerializeBookingDetails(List<BookingDetails> bd, string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<BookingDetails>));
                using (TextWriter writer = new StreamWriter(filePath))
                {
                    serializer.Serialize(writer, bd);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private List<BookingDetails> DeserializeBookingDetails(string filePath)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<BookingDetails>));
                using (TextReader reader = new StreamReader(filePath))
                {
                    return (List<BookingDetails>)serializer.Deserialize(reader);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
