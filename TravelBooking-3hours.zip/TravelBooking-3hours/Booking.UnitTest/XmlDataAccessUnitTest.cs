namespace Booking.UnitTest
{
    [TestClass]
    public class XmlDataAccessUnitTest
    {
        [TestMethod]
        public void SaveBooking()
        {
        }
    }
}