﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Booking.TravelApp.ViewModel
{
    public class SearchBookingViewModel : ViewModelBase
    {
        private string customerName;
        private string ticketType;
        private string source;
        private string destination;
        private ObservableCollection<BookingDetails> bookingList;
        private ObservableCollection<BookingDetails> filterList;
        private User _user;
        private IBookingData dataAccess;

        public SearchBookingViewModel(User user) 
        {
            _user = user;
            dataAccess = new XmlDataAccess();
            FilterCommand = new DelegateCommand(applyFilter);
            GetCustomerBookingHistory();
        }

        public string CustomerName
        {
            get { return customerName; }
            set
            {
                customerName = value;
                RaisePropertyChanged(nameof(CustomerName));
            }
        }

        public string TicketType
        {
            get { return ticketType; }
            set
            {
                ticketType = value;
                RaisePropertyChanged(nameof(TicketType));
            }
        }

        public string Source
        {
            get { return source; }
            set
            {
                source = value;
                RaisePropertyChanged(nameof(Source));
            }
        }

        public string Destination
        {
            get { return destination; }
            set
            {
                destination = value;
                RaisePropertyChanged(nameof(Destination));
            }
        }


        public ObservableCollection<BookingDetails> BookingList
        {
            get { return bookingList; }
            set
            {
                bookingList = value;
                RaisePropertyChanged(nameof(BookingList));
            }
        }

 
        public ObservableCollection<BookingDetails> FilterList
        {
            get { return filterList; }
            set
            {
                filterList = value;
                RaisePropertyChanged(nameof(FilterList));
            }
        }

        public DelegateCommand FilterCommand { get; set; }

        private void applyFilter()
        {

        }

        private void GetCustomerBookingHistory()
        {
            BookingList = new ObservableCollection<BookingDetails>(dataAccess.GetAllBookingDetails());
            FilterList = BookingList;
        }
    }
}
