﻿using Booking.DataAccess;
using Booking.DataAccess.DataAccess;
using Booking.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Booking.TravelApp.ViewModel
{
    public class StaffOperationsViewModel : ViewModelBase
    {
        private User userContext;
        private IBookingData dataAccess;

        public StaffOperationsViewModel(User user) 
        {
            userContext = user;
            dataAccess = new XmlDataAccess();
            BackUpCommand = new DelegateCommand(StartBackup);
        }

        public DelegateCommand BackUpCommand { get; set; }

        private void StartBackup()
        {
        }
    }
}
